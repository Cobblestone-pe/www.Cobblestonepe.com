//playername.ban.player
save.data.villager
pocketmine.plugin.player
