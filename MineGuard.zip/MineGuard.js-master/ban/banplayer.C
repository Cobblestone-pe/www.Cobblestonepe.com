//mojang.PLAYER:;server
/command=/ban
command.kickplayer
/:;savedata
/:;search:;ban"
