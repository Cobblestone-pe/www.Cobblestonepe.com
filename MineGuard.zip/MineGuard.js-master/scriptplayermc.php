Player.analyze.ban
//:kick.player
/command=/ban
