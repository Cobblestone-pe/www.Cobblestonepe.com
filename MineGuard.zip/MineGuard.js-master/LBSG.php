<"bootstrap">
<"sdcard0/games/com.mojang">
{"IP:tm.lbsg.net"}
{"PORT:19132"}
