//server
/command=/scan
Ban.scan.player
